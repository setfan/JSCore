let Person = require('./Person');

result.Person = Person;