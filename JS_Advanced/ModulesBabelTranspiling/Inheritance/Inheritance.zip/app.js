let Entity = require('./Entity');
let Person = require('./Person');
let Dog = require('./Dog');
let Student = require('./Student');


result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;




