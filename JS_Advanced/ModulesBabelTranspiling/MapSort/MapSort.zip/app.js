let mapSort = require('./sortMap');


// let map1 = new Map();
// map1.set("Stefan",true);
// map1.set("Azazel",false);
// map1.set("Bismoth",false);
// map1.set("Balrog",true);
// map1.set("Martel",true);
// console.log(mapSort(map1));
//
// let map2 = new Map();
// map2.set(3,"Pesho");
// map2.set(1,"Gosho");
// map2.set(7,"Aleks");
//
//
// console.log(mapSort(map2));
result.mapSort = mapSort;