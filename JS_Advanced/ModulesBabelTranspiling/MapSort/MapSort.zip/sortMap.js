function mapSort (map, sorter) {

  let arr = Array.from(map.entries());

  if (sorter) {
    arr.sort(sorter);

  } else {

    arr.sort((a, b) => {

      if (typeof a[0] === 'number') {
        return a[0] - b[0];

      } else {
        return a[0].localeCompare(b[0]);

      }
    });

  }

  return new Map(arr);
}

module.exports = mapSort;